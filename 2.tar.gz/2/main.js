
function btnA_onClick() {
    alert("버튼 A 클릭!");
}

function btnC_onClick() {
    alert("버튼 C 클릭!");
}

function btnD_onClick() {
    alert("버튼 D 클릭!");
}

function btnE_onClick() {
    alert("버튼 E 클릭!");
}

function btnH_onClick() {
    alert("버튼 H 클릭!");
}
